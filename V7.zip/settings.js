// ============================================
// AZX BACKEND CONFIGURATION
// ============================================

module.exports = {
    // ==================== SERVER CONFIG ====================
    PORT: 2002,
    NODE_ENV: 'production',
    
    // ==================== TELEGRAM BOT CONFIG ====================
    TELEGRAM_BOT_TOKEN: '8126542206:AAHoVsFX3QfNyCNh90_ywsn-AOZo29wnfuY',
    TELEGRAM_ADMIN_ID: '8038424443',
    
    // ==================== GITHUB BACKUP CONFIG ====================
    GITHUB_TOKEN: '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',
    GITHUB_REPO: 'aanzapi/Notif',
    
    // ==================== BACKUP CONFIG ====================
    AUTO_BACKUP: true,
    BACKUP_DELAY: 3000,
    
    // ==================== APK/UPDATE CONFIG ====================
    APK_FOLDER: './downloads',
    APK_URL_PREFIX: 'https://xii.aanzload.my.id/download/',
    BASE_URL: 'http://xii.aanzload.my.id:2003',
    
    // ==================== DATABASE ====================
    DB_FILE: './tokens.json',
    
    // ==================== LOGGING ====================
    LOG_LEVEL: 'info'
};