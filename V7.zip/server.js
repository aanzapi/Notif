// ============================================
// AZX NOTIF BACKEND - WITH TELEGRAM BOT
// ============================================

const express = require('express');
const admin = require('firebase-admin');
const cors = require('cors');
const fs = require('fs');
const path = require('path');
const { Telegraf } = require('telegraf');
const axios = require('axios');
const FormData = require('form-data');
const multer = require('multer');
const https = require('https');
const { extract } = require('extract-zip');

// Load config
const config = require('./settings.js');

console.log('========================================');
console.log('🚀 AZX NOTIF BACKEND WITH TELEGRAM BOT');
console.log('========================================');
console.log(`📡 Port: ${config.PORT}`);
console.log(`🤖 Telegram Bot: ${config.TELEGRAM_BOT_TOKEN ? 'ACTIVE' : 'DISABLED'}`);
console.log(`📁 GitHub Repo: ${config.GITHUB_REPO || 'Not set'}`);
console.log(`💾 Database: ${config.DB_FILE}`);
console.log('========================================\n');

// Load service account
let serviceAccount;
try {
    serviceAccount = require('./service-account.json');
    console.log('✅ Service account loaded from file');
} catch (e) {
    console.error('❌ Service account tidak ditemukan!');
    console.log('📌 Letakkan file service-account.json di folder yang sama');
    process.exit(1);
}

// Initialize Firebase
admin.initializeApp({
    credential: admin.credential.cert(serviceAccount)
});

const app = express();
app.use(cors());
app.use(express.json());

// ==================== UPDATE CONFIG ====================

// Load or create update config
let updateConfig = {
    latestVersion: '8.2.0',
    minVersion: '7.0.0',
    downloadUrl: 'https://xii.aanzload.my.id/download/azx.apk',
    forceUpdate: true,
    changelog: [
        '✅ Fitur baru: Auto update!',
        '✅ Perbaikan bug',
        '✅ Performa lebih ringan'
    ],
    releaseDate: new Date().toISOString().split('T')[0]
};

try {
    if (fs.existsSync('./update_config.json')) {
        updateConfig = JSON.parse(fs.readFileSync('./update_config.json', 'utf8'));
        console.log('📦 Update config loaded');
    } else {
        fs.writeFileSync('./update_config.json', JSON.stringify(updateConfig, null, 2));
        console.log('📦 Update config created');
    }
} catch (e) {
    console.error('Error loading update config:', e.message);
}

// ==================== MEDIAFIRE DOWNLOAD & EXTRACT ====================

// Extract download URL dari MediaFire page (Method yang lebih baik)
async function getMediaFireDownloadUrl(url) {
    return new Promise((resolve, reject) => {
        https.get(url, (response) => {
            let data = '';
            response.on('data', chunk => data += chunk);
            response.on('end', () => {
                const linkMatches = data.match(/href="(https:\/\/download\d+\.mediafire\.com\/[^"]+)"/g);
                if (linkMatches && linkMatches.length > 0) {
                    const downloadUrl = linkMatches[0].match(/https:\/\/[^"]+/)[0];
                    return resolve(downloadUrl);
                }
                
                const buttonMatches = data.match(/<a[^>]*class="input[^>]*href="([^"]+)"/i);
                if (buttonMatches && buttonMatches[1]) {
                    return resolve(buttonMatches[1]);
                }
                
                const jsMatches = data.match(/"download_url":"([^"]+)"/g);
                if (jsMatches && jsMatches.length > 0) {
                    const downloadUrl = jsMatches[0].match(/"download_url":"([^"]+)"/)[1];
                    const decoded = downloadUrl.replace(/\\u002f/g, '/').replace(/\\u002e/g, '.');
                    return resolve(decoded);
                }
                
                const pattern = /https:\/\/download\.mediafire\.com\/[a-zA-Z0-9\/\.\-\_]+/g;
                const matches = data.match(pattern);
                if (matches && matches.length > 0) {
                    return resolve(matches[0]);
                }
                
                reject(new Error('Cannot extract download URL from MediaFire page'));
            });
        }).on('error', reject);
    });
}

// Download file dari URL
function downloadFile(url, destPath) {
    return new Promise((resolve, reject) => {
        const file = fs.createWriteStream(destPath);
        const protocol = url.startsWith('https') ? https : require('http');
        
        protocol.get(url, (response) => {
            if (response.statusCode === 302 || response.statusCode === 301) {
                downloadFile(response.headers.location, destPath).then(resolve).catch(reject);
                return;
            }
            
            response.pipe(file);
            file.on('finish', () => {
                file.close();
                resolve();
            });
            file.on('error', reject);
        }).on('error', reject);
    });
}

// Extract ZIP dan cari APK
async function extractAndFindApk(zipPath, extractTo) {
    await extract(zipPath, { dir: extractTo });
    
    const files = fs.readdirSync(extractTo);
    const apkFile = files.find(f => f.endsWith('.apk'));
    
    if (!apkFile) {
        throw new Error('No APK file found in ZIP');
    }
    
    return {
        apkPath: path.join(extractTo, apkFile),
        apkName: apkFile
    };
}

// ==================== DATABASE FUNCTIONS ====================

// Load tokens from file
function loadTokens() {
    try {
        if (fs.existsSync(config.DB_FILE)) {
            const data = fs.readFileSync(config.DB_FILE, 'utf8');
            const json = JSON.parse(data);
            console.log(`📂 Loaded ${json.tokens.length} tokens from database`);
            return json.tokens;
        } else {
            console.log('📂 Creating new database...');
            return [];
        }
    } catch (e) {
        console.error('❌ Failed to load database:', e.message);
        return [];
    }
}

// Save tokens to file
function saveTokens(tokens) {
    try {
        const data = {
            lastUpdated: new Date().toISOString(),
            totalTokens: tokens.length,
            tokens: tokens
        };
        fs.writeFileSync(config.DB_FILE, JSON.stringify(data, null, 2));
        console.log(`💾 Database saved: ${tokens.length} tokens`);
        return true;
    } catch (e) {
        console.error('❌ Failed to save database:', e.message);
        return false;
    }
}

// ==================== GITHUB BACKUP ====================

let backupTimeout = null;

function backupToGitHub() {
    if (!config.GITHUB_TOKEN || !config.GITHUB_REPO) {
        console.log('⚠️ GitHub backup skipped');
        return;
    }
    
    if (backupTimeout) clearTimeout(backupTimeout);
    
    backupTimeout = setTimeout(async () => {
        console.log('📤 Backing up to GitHub...');
        
        try {
            const content = fs.readFileSync(config.DB_FILE, 'utf8');
            const encodedContent = Buffer.from(content).toString('base64');
            
            let sha = null;
            const getFileRes = await fetch(`https://api.github.com/repos/${config.GITHUB_REPO}/contents/tokens.json`, {
                headers: {
                    'Authorization': `Bearer ${config.GITHUB_TOKEN}`,
                    'User-Agent': 'AzX-Backend'
                }
            });
            
            if (getFileRes.ok) {
                const fileData = await getFileRes.json();
                sha = fileData.sha;
            }
            
            const uploadRes = await fetch(`https://api.github.com/repos/${config.GITHUB_REPO}/contents/tokens.json`, {
                method: 'PUT',
                headers: {
                    'Authorization': `Bearer ${config.GITHUB_TOKEN}`,
                    'Content-Type': 'application/json',
                    'User-Agent': 'AzX-Backend'
                },
                body: JSON.stringify({
                    message: `Auto backup: ${new Date().toISOString()}`,
                    content: encodedContent,
                    sha: sha
                })
            });
            
            if (uploadRes.ok) {
                console.log('✅ GitHub backup successful!');
            } else {
                console.log('❌ GitHub backup failed');
            }
        } catch (e) {
            console.error('❌ Backup error:', e.message);
        }
    }, config.BACKUP_DELAY);
}

function saveTokensAndBackup(tokens) {
    saveTokens(tokens);
    if (config.AUTO_BACKUP) {
        backupToGitHub();
    }
}

// ==================== SEND NOTIFICATION ====================

async function sendNotification(title, body, targetToken = null) {
    const tokensToSend = targetToken ? [targetToken] : userTokens;

    if (tokensToSend.length === 0) {
        return {
            success: false,
            message: 'No devices registered'
        };
    }

    try {
        let successCount = 0;
        let failureCount = 0;
        let invalidTokens = [];

        // Maksimal 500 token per request Firebase
        const chunkSize = 500;

        // Loop per batch
        for (let i = 0; i < tokensToSend.length; i += chunkSize) {

            const chunkTokens = tokensToSend.slice(i, i + chunkSize);

            const message = {
                notification: {
                    title,
                    body
                },
                tokens: chunkTokens
            };

            const response = await admin.messaging().sendEachForMulticast(message);

            successCount += response.successCount;
            failureCount += response.failureCount;

            // Cek token invalid
            if (response.failureCount > 0) {

                response.responses.forEach((resp, idx) => {

                    if (
                        !resp.success &&
                        (
                            resp.error?.code === 'messaging/registration-token-not-registered' ||
                            resp.error?.code === 'messaging/invalid-registration-token'
                        )
                    ) {
                        invalidTokens.push(chunkTokens[idx]);
                    }

                });

            }

            console.log(
                `📦 Batch ${Math.floor(i / chunkSize) + 1} | ` +
                `Success: ${response.successCount} | ` +
                `Failed: ${response.failureCount}`
            );
        }

        // Hapus token invalid
        if (invalidTokens.length > 0) {

            console.log(`🗑️ Removing ${invalidTokens.length} invalid tokens`);

            userTokens = userTokens.filter(
                token => !invalidTokens.includes(token)
            );

            saveTokensAndBackup(userTokens);
        }

        return {
            success: true,
            successCount,
            failureCount,
            removedInvalid: invalidTokens.length,
            message:
                `Notification sent successfully!\n` +
                `✅ Success: ${successCount}\n` +
                `❌ Failed: ${failureCount}\n` +
                `🗑️ Removed Invalid: ${invalidTokens.length}`
        };

    } catch (error) {

        console.error('❌ Send error:', error);

        return {
            success: false,
            message: error.message
        };
    }
}
// ==================== API ENDPOINTS ====================

// Health check
app.get('/', (req, res) => {
    res.json({
        status: 'running',
        uptime: process.uptime(),
        devices: userTokens.length,
        timestamp: new Date().toISOString()
    });
});

// Check update endpoint
app.get('/check-update', (req, res) => {
    const { version } = req.query;
    
    const needUpdate = version !== updateConfig.latestVersion;
    const isForce = updateConfig.forceUpdate;
    const isDeprecated = version < updateConfig.minVersion;
    
    res.json({
        success: true,
        needUpdate: needUpdate,
        forceUpdate: isForce || isDeprecated,
        latestVersion: updateConfig.latestVersion,
        currentVersion: version,
        downloadUrl: updateConfig.downloadUrl,
        changelog: updateConfig.changelog,
        releaseDate: updateConfig.releaseDate,
        message: isForce || isDeprecated 
            ? 'Wajib update! Versi lama sudah tidak support.'
            : 'Update tersedia! Silahkan update ke versi terbaru.'
    });
});

// Download APK
app.get('/download-app', (req, res) => {
    const apkPath = path.join(__dirname, 'downloads', 'azx.apk');
    
    if (fs.existsSync(apkPath)) {
        res.download(apkPath, `azx-v${updateConfig.latestVersion}.apk`);
    } else {
        res.status(404).json({ error: 'APK tidak ditemukan. Upload via Telegram /upload' });
    }
});

// Save device token
app.post('/save-token', (req, res) => {
    const { token } = req.body;
    
    if (!token) {
        return res.status(400).json({ error: 'Token required' });
    }
    
    if (!userTokens.includes(token)) {
        userTokens.push(token);
        saveTokensAndBackup(userTokens);
        console.log(`✅ NEW TOKEN: ${token.substring(0, 35)}...`);
        console.log(`📱 Total devices: ${userTokens.length}`);
    }
    
    res.json({ 
        success: true, 
        message: 'Token saved',
        totalDevices: userTokens.length 
    });
});

// Send notification (tanpa gambar)
app.post('/send-notif', async (req, res) => {
    const { title, body } = req.body;
    const result = await sendNotification(title || 'AzX Notification', body || 'You have a new notification!');
    res.json(result);
});

// Send notification with image
app.post('/send-notif-with-image', async (req, res) => {
    const { title, body, imageUrl } = req.body;
    
    if (userTokens.length === 0) {
        return res.json({ success: false, message: 'No devices registered', sent: 0 });
    }
    
    const result = await sendNotification(title || 'AzX Notification', body || 'Hello!', null, imageUrl);
    
    res.json({ 
        success: result.success, 
        sent: result.successCount,
        failed: result.failureCount,
        message: result.message
    });
});

// List devices
app.get('/devices', (req, res) => {
    res.json({
        total: userTokens.length,
        devices: userTokens.map(t => t.substring(0, 35) + '...')
    });
});

// Remove token
app.post('/remove-token', (req, res) => {
    const { token } = req.body;
    userTokens = userTokens.filter(t => t !== token);
    saveTokensAndBackup(userTokens);
    res.json({ success: true, totalDevices: userTokens.length });
});

// Manual backup
app.post('/backup', (req, res) => {
    saveTokensAndBackup(userTokens);
    res.json({ success: true, message: 'Backup triggered' });
});

// ==================== TELEGRAM BOT ====================

let bot = null;
let TELEGRAM_ADMIN_ID = null;
const uploadDir = './downloads';

// Create downloads folder
if (!fs.existsSync(uploadDir)) {
    fs.mkdirSync(uploadDir, { recursive: true });
    console.log('📁 Downloads folder created');
}

if (config.TELEGRAM_BOT_TOKEN && config.TELEGRAM_ADMIN_ID) {
    bot = new Telegraf(config.TELEGRAM_BOT_TOKEN);
    TELEGRAM_ADMIN_ID = config.TELEGRAM_ADMIN_ID;
    
    // Start bot
    bot.start(async (ctx) => {
        const userId = ctx.from.id.toString();
        const firstName = ctx.from.first_name || 'User';
        
        if (userId === TELEGRAM_ADMIN_ID) {
            await ctx.replyWithHTML(`
<b>🤖 AZX BOT ACTIVATED</b>
━━━━━━━━━━━━━━━━━━━━━
Hello <b>${firstName}</b>, welcome back to AzX Bot!

<b>📋 SYSTEM STATUS</b>
├ 📱 Devices: ${userTokens.length}
├ 🔄 Version: ${updateConfig.latestVersion}
└ ⚡ Status: Active

<b>📌 QUICK COMMANDS</b>
├ /sendnotif - Send text notification
├ /sendimage - Send notification with image
├ /devices - List all devices
├ /stats - System statistics
├ /upload - Upload APK from MediaFire
└ /info - Show update config

Type <b>/help</b> to see all commands
━━━━━━━━━━━━━━━━━━━━━
<i>AzX Notification System</i>
            `);
        } else {
            await ctx.replyWithHTML(`
<b>❌ ACCESS DENIED</b>
━━━━━━━━━━━━━━━━━━━━━
Hello <b>${firstName}</b>, you are not authorized to use this bot.

Please contact the administrator for access.
━━━━━━━━━━━━━━━━━━━━━
            `);
        }
    });
    
    // ==================== COMMAND: SENDNOTIF (TEKS SAJA) ====================
    bot.command('sendnotif', async (ctx) => {
        const userId = ctx.from.id.toString();
        if (userId !== TELEGRAM_ADMIN_ID) return ctx.replyWithHTML('<b>❌ Unauthorized</b>');
        
        const args = ctx.message.text.split(' ').slice(1).join(' ');
        const [title, body] = args.split('|');
        
        if (!title || !body) {
            return ctx.replyWithHTML(`
<b>❌ INVALID USAGE</b>
━━━━━━━━━━━━━━━━━━━━━
Format: <code>/sendnotif Title|Message</code>

<b>Example:</b>
<code>/sendnotif Update|Ada versi baru tersedia!</code>
━━━━━━━━━━━━━━━━━━━━━
            `);
        }
        
        await ctx.replyWithHTML(`
<b>📨 SENDING NOTIFICATION</b>
━━━━━━━━━━━━━━━━━━━━━
📌 <b>Title:</b> ${title}
📝 <b>Message:</b> ${body}
📱 <b>Target:</b> ${userTokens.length} device(s)
━━━━━━━━━━━━━━━━━━━━━
            `);
        
        const result = await sendNotification(title, body);
        
        if (result.success) {
            let reply = `<b>✅ NOTIFICATION SENT</b>\n━━━━━━━━━━━━━━━━━━━━━\n${result.message}`;
            if (result.removedInvalid > 0) {
                reply += `\n🗑️ Removed ${result.removedInvalid} invalid tokens`;
            }
            await ctx.replyWithHTML(reply);
        } else {
            await ctx.replyWithHTML(`<b>❌ FAILED</b>\n━━━━━━━━━━━━━━━━━━━━━\n${result.message}`);
        }
    });
    
    // ==================== COMMAND: SENDIMAGE (DENGAN GAMBAR) ====================
    bot.command('sendimage', async (ctx) => {
        const userId = ctx.from.id.toString();
        
        if (userId !== TELEGRAM_ADMIN_ID) {
            return ctx.replyWithHTML('<b>❌ Unauthorized</b>');
        }
        
        let title = '';
        let body = '';
        let imageUrl = null;
        
        try {
            // CEK APAKAH ADA REPLY KE FOTO
            if (ctx.message.reply_to_message && ctx.message.reply_to_message.photo) {
                // Ambil foto terbesar
                const photo = ctx.message.reply_to_message.photo[ctx.message.reply_to_message.photo.length - 1];
                const fileId = photo.file_id;
                
                // Dapatkan link foto
                const file = await ctx.telegram.getFile(fileId);
                imageUrl = `https://api.telegram.org/file/bot${config.TELEGRAM_BOT_TOKEN}/${file.file_path}`;
                
                // Ambil caption sebagai title|body
                const caption = ctx.message.reply_to_message.caption || '';
                const parts = caption.split('|');
                title = parts[0]?.trim() || 'Notifikasi';
                body = parts[1]?.trim() || 'Ada pesan baru';
            } 
            // ATAU DARI COMMAND TEXT
            else {
                const messageText = ctx.message.text;
                const args = messageText.replace('/sendimage', '').trim();
                
                if (!args) {
                    return ctx.replyWithHTML(`
<b>❌ INVALID USAGE</b>
━━━━━━━━━━━━━━━━━━━━━
<b>Format 1 (dengan URL gambar):</b>
<code>/sendimage Title|Message|https://example.com/image.jpg</code>

<b>Format 2 (reply foto):</b>
1. Kirim foto dengan caption <code>Title|Message</code>
2. Reply foto tersebut lalu ketik <code>/sendimage</code>
━━━━━━━━━━━━━━━━━━━━━
                    `);
                }
                
                const parts = args.split('|');
                
                // Cek apakah ada URL gambar
                if (parts.length >= 3) {
                    const possibleUrl = parts[2].trim();
                    if (possibleUrl.startsWith('http://') || possibleUrl.startsWith('https://')) {
                        title = parts[0].trim();
                        body = parts[1].trim();
                        imageUrl = possibleUrl;
                    } else {
                        title = parts[0].trim();
                        body = parts.slice(1).join('|').trim();
                    }
                } 
                // Format biasa title|body
                else if (parts.length >= 2) {
                    title = parts[0].trim();
                    body = parts[1].trim();
                }
                else {
                    return ctx.replyWithHTML('<b>❌ Format salah! Gunakan: /sendimage Title|Body atau /sendimage Title|Body|https://gambar.jpg</b>');
                }
            }
            
            if (!title || !body) {
                return ctx.replyWithHTML('<b>❌ Title dan Body wajib diisi!</b>');
            }
            
            await ctx.replyWithHTML(`
<b>📨 SENDING NOTIFICATION WITH IMAGE</b>
━━━━━━━━━━━━━━━━━━━━━
📌 <b>Title:</b> ${title}
📝 <b>Message:</b> ${body}
🖼️ <b>Image:</b> ${imageUrl ? 'Yes' : 'No'}
📱 <b>Target:</b> ${userTokens.length} device(s)
━━━━━━━━━━━━━━━━━━━━━
            `);
            
            // KIRIM VIA API KE FCM
            const response = await fetch(`http://localhost:${config.PORT}/send-notif-with-image`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ title, body, imageUrl })
            });
            
            const result = await response.json();
            
            if (result.success) {
                await ctx.replyWithHTML(`<b>✅ NOTIFICATION SENT</b>\n━━━━━━━━━━━━━━━━━━━━━\nTerkirim ke ${result.sent} device(s)`);
            } else {
                await ctx.replyWithHTML(`<b>❌ FAILED</b>\n━━━━━━━━━━━━━━━━━━━━━\n${result.error || 'Unknown error'}`);
            }
            
        } catch (error) {
            console.error('Error in sendimage command:', error);
            await ctx.replyWithHTML(`<b>❌ ERROR</b>\n━━━━━━━━━━━━━━━━━━━━━\n${error.message}`);
        }
    });
    
    // Command: devices
    bot.command('devices', async (ctx) => {
        const userId = ctx.from.id.toString();
        if (userId !== TELEGRAM_ADMIN_ID) return ctx.replyWithHTML('<b>❌ Unauthorized</b>');
        
        if (userTokens.length === 0) {
            return ctx.replyWithHTML(`
<b>📱 DEVICE LIST</b>
━━━━━━━━━━━━━━━━━━━━━
No devices registered yet.
━━━━━━━━━━━━━━━━━━━━━
            `);
        }
        
        let devicesList = '';
        userTokens.forEach((token, i) => {
            const shortToken = token.substring(0, 35) + '...';
            devicesList += `├ ${i+1}. <code>${shortToken}</code>\n`;
        });
        
        await ctx.replyWithHTML(`
<b>📱 REGISTERED DEVICES</b>
━━━━━━━━━━━━━━━━━━━━━
<b>Total:</b> ${userTokens.length} device(s)
━━━━━━━━━━━━━━━━━━━━━
${devicesList}
━━━━━━━━━━━━━━━━━━━━━
            `);
    });
    
    // Command: stats
    bot.command('stats', async (ctx) => {
        const userId = ctx.from.id.toString();
        if (userId !== TELEGRAM_ADMIN_ID) return ctx.replyWithHTML('<b>❌ Unauthorized</b>');
        
        const stats = fs.statSync(config.DB_FILE);
        const updateConfigData = JSON.parse(fs.readFileSync('./update_config.json', 'utf8'));
        
        await ctx.replyWithHTML(`
<b>📊 SYSTEM STATISTICS</b>
━━━━━━━━━━━━━━━━━━━━━
<b>📱 DATABASE</b>
├ Devices: ${userTokens.length}
├ File size: ${(stats.size / 1024).toFixed(2)} KB
└ Last update: ${new Date(stats.mtime).toLocaleString()}

<b>📦 UPDATE CONFIG</b>
├ Version: ${updateConfigData.latestVersion}
├ Force update: ${updateConfigData.forceUpdate ? 'ON' : 'OFF'}
├ Min version: ${updateConfigData.minVersion || '7.0.0'}
└ Release date: ${updateConfigData.releaseDate}

<b>📥 DOWNLOAD URL</b>
<code>${updateConfigData.downloadUrl.substring(0, 60)}...</code>
━━━━━━━━━━━━━━━━━━━━━
            `);
    });
    
    // Command: backup
    bot.command('backup', async (ctx) => {
        const userId = ctx.from.id.toString();
        if (userId !== TELEGRAM_ADMIN_ID) return ctx.replyWithHTML('<b>❌ Unauthorized</b>');
        
        await ctx.replyWithHTML('<b>📤 MANUAL BACKUP</b>\n━━━━━━━━━━━━━━━━━━━━━\n⏳ Triggering backup to GitHub...');
        saveTokensAndBackup(userTokens);
        await ctx.replyWithHTML('<b>✅ BACKUP COMPLETED</b>\n━━━━━━━━━━━━━━━━━━━━━\nDatabase has been backed up to GitHub.');
    });
    
    // Command: upload from MediaFire
    bot.command('upload', async (ctx) => {
        const userId = ctx.from.id.toString();
        if (userId !== TELEGRAM_ADMIN_ID) return ctx.replyWithHTML('<b>❌ Unauthorized</b>');
        
        const args = ctx.message.text.split(' ').slice(1).join(' ');
        const url = args.trim();
        
        if (!url) {
            return ctx.replyWithHTML(`
<b>❌ INVALID USAGE</b>
━━━━━━━━━━━━━━━━━━━━━
Format: <code>/upload &lt;mediafire_url&gt;</code>

<b>Example:</b>
<code>/upload https://www.mediafire.com/file/xxxxx/app.zip</code>
━━━━━━━━━━━━━━━━━━━━━
            `);
        }
        
        if (!url.includes('mediafire.com')) {
            return ctx.replyWithHTML('<b>❌ ERROR</b>\n━━━━━━━━━━━━━━━━━━━━━\nOnly MediaFire links are supported!');
        }
        
        await ctx.replyWithHTML(`
<b>📥 PROCESSING MEDIAFIRE LINK</b>
━━━━━━━━━━━━━━━━━━━━━
⏳ This may take a few minutes...
🔗 URL: <code>${url.substring(0, 50)}...</code>
━━━━━━━━━━━━━━━━━━━━━
        `);
        
        try {
            await ctx.replyWithHTML('<b>🔗 Extracting download link...</b>');
            
            let downloadUrl;
            try {
                downloadUrl = await getMediaFireDownloadUrl(url);
            } catch (e) {
                console.log('Primary method failed, trying alternative...');
                downloadUrl = await getMediaFireDownloadUrl(url);
            }
            
            console.log(`Download URL extracted: ${downloadUrl}`);
            await ctx.replyWithHTML('<b>✅ Download link extracted!</b>');
            
            await ctx.replyWithHTML('<b>📦 Downloading ZIP file...</b>\n⏳ Large files may take longer...');
            const tempZip = path.join(uploadDir, 'temp_update.zip');
            await downloadFile(downloadUrl, tempZip);
            
            const stats = fs.statSync(tempZip);
            const zipSizeMB = (stats.size / 1024 / 1024).toFixed(2);
            await ctx.replyWithHTML(`<b>📦 ZIP downloaded</b>\n━━━━━━━━━━━━━━━━━━━━━\nSize: ${zipSizeMB} MB`);
            
            await ctx.replyWithHTML('<b>📂 Extracting files...</b>');
            const extractDir = path.join(uploadDir, 'extracted');
            if (fs.existsSync(extractDir)) fs.rmSync(extractDir, { recursive: true });
            fs.mkdirSync(extractDir, { recursive: true });
            
            const { apkPath, apkName } = await extractAndFindApk(tempZip, extractDir);
            
            const finalApkPath = path.join(uploadDir, 'azx.apk');
            fs.copyFileSync(apkPath, finalApkPath);
            
            fs.unlinkSync(tempZip);
            fs.rmSync(extractDir, { recursive: true });
            
            const sizeMB = (fs.statSync(finalApkPath).size / 1024 / 1024).toFixed(2);
            const downloadUrlFinal = `${config.APK_URL_PREFIX || 'https://xii.aanzload.my.id/download/'}azx.apk`;
            
            updateConfig.downloadUrl = downloadUrlFinal;
            fs.writeFileSync('./update_config.json', JSON.stringify(updateConfig, null, 2));
            
            await ctx.replyWithHTML(`
<b>✅ APK UPLOAD SUCCESS!</b>
━━━━━━━━━━━━━━━━━━━━━
<b>📦 File:</b> ${apkName}
<b>💾 Size:</b> ${sizeMB} MB
<b>🔗 URL:</b> <code>${downloadUrlFinal}</code>

<b>📱 NEXT STEPS:</b>
├ 1. Update version with <code>/setversion</code>
└ 2. Notify users to update
━━━━━━━━━━━━━━━━━━━━━
            `);
            
            console.log(`✓ APK from MediaFire: ${sizeMB} MB`);
            
        } catch (error) {
            console.error('Upload error:', error);
            await ctx.replyWithHTML(`
<b>❌ UPLOAD FAILED</b>
━━━━━━━━━━━━━━━━━━━━━
<b>Error:</b> ${error.message}

<b>💡 TIPS:</b>
├ 1. Make sure the link is correct
├ 2. File should be a ZIP containing APK
└ 3. Try a different file host
━━━━━━━━━━━━━━━━━━━━━
            `);
        }
    });
    
    // Command: setversion
    bot.command('setversion', async (ctx) => {
        const userId = ctx.from.id.toString();
        if (userId !== TELEGRAM_ADMIN_ID) return ctx.replyWithHTML('<b>❌ Unauthorized</b>');
        
        const version = ctx.message.text.split(' ')[1];
        if (!version) {
            return ctx.replyWithHTML(`
<b>❌ INVALID USAGE</b>
━━━━━━━━━━━━━━━━━━━━━
Format: <code>/setversion 7.2.0</code>
            `);
        }
        
        updateConfig.latestVersion = version;
        fs.writeFileSync('./update_config.json', JSON.stringify(updateConfig, null, 2));
        
        await ctx.replyWithHTML(`
<b>✅ VERSION UPDATED</b>
━━━━━━━━━━━━━━━━━━━━━
Latest version: <b>${version}</b>
━━━━━━━━━━━━━━━━━━━━━
        `);
    });
    
    // Command: seturl
    bot.command('seturl', async (ctx) => {
        const userId = ctx.from.id.toString();
        if (userId !== TELEGRAM_ADMIN_ID) return ctx.replyWithHTML('<b>❌ Unauthorized</b>');
        
        const url = ctx.message.text.split(' ')[1];
        if (!url) {
            return ctx.replyWithHTML(`
<b>❌ INVALID USAGE</b>
━━━━━━━━━━━━━━━━━━━━━
Format: <code>/seturl https://example.com/app.apk</code>
            `);
        }
        
        updateConfig.downloadUrl = url;
        fs.writeFileSync('./update_config.json', JSON.stringify(updateConfig, null, 2));
        
        await ctx.replyWithHTML(`
<b>✅ URL UPDATED</b>
━━━━━━━━━━━━━━━━━━━━━
Download URL: <code>${url}</code>
━━━━━━━━━━━━━━━━━━━━━
        `);
    });
    
    // Command: setforce
    bot.command('setforce', async (ctx) => {
        const userId = ctx.from.id.toString();
        if (userId !== TELEGRAM_ADMIN_ID) return ctx.replyWithHTML('<b>❌ Unauthorized</b>');
        
        const value = ctx.message.text.split(' ')[1];
        if (!value || !['true', 'false'].includes(value)) {
            return ctx.replyWithHTML(`
<b>❌ INVALID USAGE</b>
━━━━━━━━━━━━━━━━━━━━━
Format: <code>/setforce true</code> or <code>/setforce false</code>
            `);
        }
        
        updateConfig.forceUpdate = value === 'true';
        fs.writeFileSync('./update_config.json', JSON.stringify(updateConfig, null, 2));
        
        await ctx.replyWithHTML(`
<b>✅ FORCE UPDATE SET</b>
━━━━━━━━━━━━━━━━━━━━━
Force update: <b>${value.toUpperCase()}</b>
━━━━━━━━━━━━━━━━━━━━━
        `);
    });
    
    // Command: setchangelog
    bot.command('setchangelog', async (ctx) => {
        const userId = ctx.from.id.toString();
        if (userId !== TELEGRAM_ADMIN_ID) return ctx.replyWithHTML('<b>❌ Unauthorized</b>');
        
        const changelog = ctx.message.text.split(' ').slice(1).join(' ');
        if (!changelog) {
            return ctx.replyWithHTML(`
<b>❌ INVALID USAGE</b>
━━━━━━━━━━━━━━━━━━━━━
Format: <code>/setchangelog New feature 1 | New feature 2</code>

<b>Example:</b>
<code>/setchangelog Added dark mode | Fixed crash | Improved performance</code>
            `);
        }
        
        const items = changelog.split('|').map(item => `✅ ${item.trim()}`);
        updateConfig.changelog = items;
        fs.writeFileSync('./update_config.json', JSON.stringify(updateConfig, null, 2));
        
        let changelogText = '';
        items.forEach(item => {
            changelogText += `├ ${item}\n`;
        });
        
        await ctx.replyWithHTML(`
<b>✅ CHANGELOG UPDATED</b>
━━━━━━━━━━━━━━━━━━━━━
${changelogText}
━━━━━━━━━━━━━━━━━━━━━
        `);
    });
    
    // Command: info
    bot.command('info', async (ctx) => {
        const userId = ctx.from.id.toString();
        if (userId !== TELEGRAM_ADMIN_ID) return ctx.replyWithHTML('<b>❌ Unauthorized</b>');
        
        let changelogText = '';
        updateConfig.changelog.forEach((item) => {
            changelogText += `├ ${item}\n`;
        });
        
        await ctx.replyWithHTML(`
<b>📦 UPDATE CONFIGURATION</b>
━━━━━━━━━━━━━━━━━━━━━
<b>📌 VERSION</b>
├ Latest: <b>${updateConfig.latestVersion}</b>
├ Min required: <b>${updateConfig.minVersion || '7.0.0'}</b>
└ Force update: <b>${updateConfig.forceUpdate ? 'ON' : 'OFF'}</b>

<b>📥 DOWNLOAD URL</b>
<code>${updateConfig.downloadUrl}</code>

<b>📅 RELEASE DATE</b>
├ ${updateConfig.releaseDate}

<b>📝 CHANGELOG</b>
${changelogText || '├ No changelog available'}
━━━━━━━━━━━━━━━━━━━━━
        `);
    });
    
    // Command: help
    bot.command('help', async (ctx) => {
        const userId = ctx.from.id.toString();
        if (userId !== TELEGRAM_ADMIN_ID) return ctx.replyWithHTML('<b>❌ Unauthorized</b>');
        
        await ctx.replyWithHTML(`
<b>🤖 AZX BOT COMMANDS</b>
━━━━━━━━━━━━━━━━━━━━━
<b>📨 NOTIFICATION</b>
├ <code>/sendnotif Title|Message</code> - Send text notification
├ <code>/sendimage Title|Message|url</code> - Send notification with image
└ <code>/sendimage</code> (reply to photo) - Send photo as notification

<b>📱 DEVICE MANAGEMENT</b>
├ <code>/devices</code> - List registered devices
└ <code>/stats</code> - Show system statistics

<b>📦 UPDATE MANAGEMENT</b>
├ <code>/upload &lt;mediafire_url&gt;</code> - Upload APK from MediaFire
├ <code>/setversion 7.2.0</code> - Update latest version
├ <code>/seturl https://...</code> - Update download URL
├ <code>/setforce true/false</code> - Force update on/off
├ <code>/setchangelog text|text</code> - Update changelog
└ <code>/info</code> - Show current config

<b>💾 BACKUP</b>
├ <code>/backup</code> - Manual backup to GitHub

<b>ℹ️ GENERAL</b>
├ <code>/start</code> - Welcome message
├ <code>/help</code> - Show this help
└ <code>/info</code> - Show update config
━━━━━━━━━━━━━━━━━━━━━
<i>© AzX Notification System</i>
        `);
    });
    
    // Launch bot
    bot.launch();
    console.log('🤖 Telegram Bot Started!');
    
    // Enable graceful stop
    process.once('SIGINT', () => bot.stop('SIGINT'));
    process.once('SIGTERM', () => bot.stop('SIGTERM'));
} else {
    console.log('⚠️ Telegram bot disabled (TOKEN or ADMIN_ID not set)');
}

// ==================== CONSOLE COMMANDS ====================

function startConsoleCommands() {
    const rl = require('readline').createInterface({
        input: process.stdin,
        output: process.stdout
    });
    
    console.log('\n💬 CONSOLE COMMANDS READY');
    console.log('========================================');
    console.log('  /sendnotif Title|Message');
    console.log('  /devices');
    console.log('  /backup');
    console.log('  /stats');
    console.log('  /help');
    console.log('  /clear');
    console.log('========================================\n');
    
    rl.on('line', async (input) => {
        const cmd = input.trim().toLowerCase();
        
        if (cmd.startsWith('/sendnotif')) {
            const args = input.substring(11).trim();
            const [title, body] = args.split('|');
            
            if (!title || !body) {
                console.log('❌ Usage: /sendnotif Title|Message');
                return;
            }
            
            console.log(`\n📨 Sending to ${userTokens.length} device(s)...`);
            const result = await sendNotification(title, body);
            console.log(result.success ? `✅ ${result.message}` : `❌ ${result.message}`);
        }
        else if (cmd === '/devices') {
            console.log(`\n📱 Total devices: ${userTokens.length}`);
            userTokens.forEach((token, i) => {
                console.log(`   ${i+1}. ${token.substring(0, 45)}...`);
            });
        }
        else if (cmd === '/backup') {
            console.log('📤 Manual backup triggered...');
            saveTokensAndBackup(userTokens);
            console.log('✅ Backup completed!');
        }
        else if (cmd === '/stats') {
            const stats = fs.statSync(config.DB_FILE);
            console.log(`\n📊 Total devices: ${userTokens.length}`);
            console.log(`💾 File size: ${(stats.size / 1024).toFixed(2)} KB`);
        }
        else if (cmd === '/help') {
            console.log('\n📋 Commands: /sendnotif, /devices, /backup, /stats, /clear');
        }
        else if (cmd === '/clear') {
            console.clear();
        }
    });
}

// ==================== START SERVER ====================

let userTokens = loadTokens();

app.listen(config.PORT, '0.0.0.0', () => {
    console.log('========================================');
    console.log('🚀 SERVER IS RUNNING');
    console.log('========================================');
    console.log(`📡 Port: ${config.PORT}`);
    console.log(`📱 Devices: ${userTokens.length}`);
    console.log(`💾 Database: ${config.DB_FILE}`);
    console.log(`📦 Latest Version: ${updateConfig.latestVersion}`);
    console.log('========================================');
    console.log('🌐 API Endpoints:');
    console.log(`   GET  /              - Health check`);
    console.log(`   GET  /check-update  - Check app update`);
    console.log(`   GET  /download-app  - Download APK`);
    console.log(`   POST /save-token    - Save device token`);
    console.log(`   POST /send-notif    - Send text notification`);
    console.log(`   POST /send-notif-with-image - Send notification with image`);
    console.log(`   GET  /devices       - List devices`);
    console.log('========================================\n');
    
    startConsoleCommands();
});